import java.util.*;

public class ReservationSystem {

    Scanner sc = new Scanner(System.in);
    ReservationDAO dao = new ReservationDAO();

    public void makeReservation() {
        System.out.print("Enter Passenger Name: ");
        String name = sc.nextLine();

        System.out.print("Enter Train Number: ");
        String trainNumber = sc.nextLine();

        System.out.print("Enter Class Type (AC/Sleeper/General): ");
        String classType = sc.nextLine();

        System.out.print("Enter Journey Date (DD-MM-YYYY): ");
        String date = sc.nextLine();

        System.out.print("From: ");
        String from = sc.nextLine();

        System.out.print("To: ");
        String to = sc.nextLine();

        Reservation r = new Reservation(name, trainNumber, classType, date, from, to);
        dao.insertReservation(r);
    }

    public void cancelReservation() {
        System.out.print("Enter Reservation ID to Cancel: ");
        int id = sc.nextInt();
        sc.nextLine();

        boolean result = dao.deleteReservation(id);

        if (result)
            System.out.println("❌ Reservation Cancelled Successfully!");
        else
            System.out.println("⚠ Reservation Not Found!");
    }

    public void viewReservations() {
        ArrayList<Reservation> list = dao.getAllReservations();

        if (list.isEmpty()) {
            System.out.println("No reservations found!");
            return;
        }

        System.out.println("\n------ Reservations List ------");
        for (Reservation r : list) {
            System.out.println("ID: " + r.id + ", Name: " + r.name +
                               ", Train No: " + r.trainNumber +
                               ", Class: " + r.classType +
                               ", Date: " + r.date +
                               ", From: " + r.from +
                               ", To: " + r.to);
        }
    }
}
