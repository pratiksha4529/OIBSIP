public class Reservation {
    int id;
    String name;
    String trainNumber;
    String classType;
    String date;
    String from;
    String to;

    public Reservation(String name, String trainNumber, String classType, 
                       String date, String from, String to) {
        this.name = name;
        this.trainNumber = trainNumber;
        this.classType = classType;
        this.date = date;
        this.from = from;
        this.to = to;
    }

    public Reservation(int id, String name, String trainNumber, String classType, 
                       String date, String from, String to) {
        this(name, trainNumber, classType, date, from, to);
        this.id = id;
    }
}
