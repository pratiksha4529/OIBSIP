public class User {

    private String username = "admin";
    private String password = "12345";

    public boolean login(String u, String p) {
        return username.equals(u) && password.equals(p);
    }
}
