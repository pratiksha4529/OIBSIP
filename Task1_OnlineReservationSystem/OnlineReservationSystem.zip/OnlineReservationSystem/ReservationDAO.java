import java.sql.*;
import java.util.ArrayList;

public class ReservationDAO {

    public void insertReservation(Reservation r) {
        String query = "INSERT INTO reservations (passenger_name, train_number, class_type, journey_date, from_station, to_station) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, r.name);
            ps.setString(2, r.trainNumber);
            ps.setString(3, r.classType);
            ps.setString(4, r.date);
            ps.setString(5, r.from);
            ps.setString(6, r.to);

            ps.executeUpdate();
            System.out.println("✔ Reservation Stored Successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean deleteReservation(int id) {
        String query = "DELETE FROM reservations WHERE id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setInt(1, id);
            int rows = ps.executeUpdate();

            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public ArrayList<Reservation> getAllReservations() {
        String query = "SELECT * FROM reservations";
        ArrayList<Reservation> list = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(query)) {

            while (rs.next()) {
                list.add(new Reservation(
                    rs.getInt("id"),
                    rs.getString("passenger_name"),
                    rs.getString("train_number"),
                    rs.getString("class_type"),
                    rs.getString("journey_date"),
                    rs.getString("from_station"),
                    rs.getString("to_station")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
