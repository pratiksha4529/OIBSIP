import java.sql.*;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/reservationdb";
    private static final String USER = "root";
    private static final String PASS = "your_password";

    public static Connection getConnection() {
        Connection con = null;
        try {
            con = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("✅ Database Connected Successfully!");
        } catch (Exception e) {
            System.out.println("❌ Database Connection Failed!");
            e.printStackTrace();
        }
        return con;
    }
}
