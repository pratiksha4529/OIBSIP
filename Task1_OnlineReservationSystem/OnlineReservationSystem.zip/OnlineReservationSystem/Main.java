import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        User user = new User();
        ReservationSystem rs = new ReservationSystem();

        System.out.println("---- ONLINE RESERVATION SYSTEM ----");

        System.out.print("Username: ");
        String u = sc.nextLine();

        System.out.print("Password: ");
        String p = sc.nextLine();

        if (!user.login(u, p)) {
            System.out.println("❌ Login Failed!");
            return;
        }

        System.out.println("🎉 Login Successful!");

        int choice;
        do {
            System.out.println("\n1. Make Reservation");
            System.out.println("2. Cancel Reservation");
            System.out.println("3. View Reservations");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    rs.makeReservation();
                    break;
                case 2:
                    rs.cancelReservation();
                    break;
                case 3:
                    rs.viewReservations();
                    break;
                case 4:
                    System.out.println("Thank you for using the system!");
                    break;
                default:
                    System.out.println("Invalid Option!");
            }

        } while (choice != 4);

        sc.close();
    }
}
