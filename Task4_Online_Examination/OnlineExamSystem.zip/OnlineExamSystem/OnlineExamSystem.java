import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;

// =========================================================================
// Class 1: User Model (Handles profile and credentials)
// =========================================================================
class User {
    private String username;
    private String password;
    private String name;
    private String email;

    public User(String username, String password, String name, String email) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.email = email;
    }

    // Getters
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getName() { return name; }
    public String getEmail() { return email; }

    // Setters (for updating profile/password)
    public void setPassword(String password) { this.password = password; }
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return "\n--- User Profile ---" +
               "\nUsername: " + username +
               "\nName: " + name +
               "\nEmail: " + email +
               "\n--------------------";
    }
}

// =========================================================================
// Class 2: Question Model (Handles question data)
// =========================================================================
class Question {
    private String text;
    private List<String> options;
    private int correctAnswerIndex; // Index of the correct option (0-based)

    public Question(String text, List<String> options, int correctAnswerIndex) {
        this.text = text;
        this.options = options;
        this.correctAnswerIndex = correctAnswerIndex;
    }

    public String getText() { return text; }
    public List<String> getOptions() { return options; }
    public int getCorrectAnswerIndex() { return correctAnswerIndex; }
}

// =========================================================================
// Class 3: Main System Logic (Handles flow, authentication, and timer)
// =========================================================================
public class OnlineExamSystem {
    // Data Storage
    private Map<String, User> users;
    private List<Question> questions;
    private Map<Integer, Integer> userAnswers; // Question Index -> User's Answer Index (1-based)

    // State Management
    private User loggedInUser = null;
    private Scanner scanner;
    private Timer timer;
    // Flag to ensure the exam is only submitted once
    private AtomicBoolean examSubmitted = new AtomicBoolean(false); 
    
    // Configuration
    private final int EXAM_DURATION_SECONDS = 60; // 1 minute duration for testing

    public OnlineExamSystem() {
        this.users = new HashMap<>();
        this.scanner = new Scanner(System.in);
        this.userAnswers = new HashMap<>();
        
        // Setup initial data (Users and Questions)
        setupUsers();
        setupQuestions();
    }
    
    // --- Initial Data Setup ---

    private void setupUsers() {
        users.put("alice", new User("alice", "pass123", "Alice Smith", "alice@test.com"));
        users.put("bob", new User("bob", "password", "Bob Johnson", "bob@test.com"));
    }

    private void setupQuestions() {
        questions = new ArrayList<>();
        // Q1
        questions.add(new Question(
            "What is the main purpose of the 'static' keyword in Java?",
            List.of("A. To allow method overloading", "B. To make variables global", "C. To declare a class member that belongs to the class itself, not to a specific instance", "D. To prevent inheritance"),
            2 // C
        ));
        // Q2
        questions.add(new Question(
            "Which of these is NOT a Java primitive data type?",
            List.of("A. int", "B. String", "C. boolean", "D. double"),
            1 // B
        ));
        // Q3
        questions.add(new Question(
            "What is the default value of a boolean variable in Java?",
            List.of("A. true", "B. false", "C. 0", "D. null"),
            1 // B
        ));
    }
    
    // --- Main Application Flow ---

    public void start() {
        System.out.println("=============================================");
        System.out.println("     WELCOME TO THE ONLINE EXAMINATION SYSTEM");
        System.out.println("=============================================");

        if (login()) {
            showMainMenu();
        }
    }
    
    // --- 1. Login Functionality ---

    private boolean login() {
        System.out.println("\n--- Login ---");
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        User user = users.get(username);
        
        if (user != null && user.getPassword().equals(password)) {
            loggedInUser = user;
            System.out.println("\n*** Login successful! Welcome, " + loggedInUser.getName() + " ***");
            return true;
        } else {
            System.out.println("\n!!! Invalid credentials. Please try again. !!!");
            return false;
        }
    }
    
    // --- Main Menu ---

    private void showMainMenu() {
        while (loggedInUser != null) {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1. Start Examination");
            System.out.println("2. Update Profile and Password");
            System.out.println("3. Logout and Close Session");
            System.out.print("Enter your choice (1-3): ");

            if (!scanner.hasNextInt()) {
                System.out.println("\n!!! Invalid input. Please enter a number from 1 to 3. !!!");
                scanner.nextLine(); // consume invalid input
                continue;
            }
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    startExam();
                    break;
                case 2:
                    updateProfile();
                    break;
                case 3:
                    logout();
                    return;
                default:
                    System.out.println("\n!!! Invalid choice. Please select an option between 1 and 3. !!!");
            }
        }
    }

    // --- 2. Update Profile and Password ---

    private void updateProfile() {
        System.out.println(loggedInUser.toString());
        System.out.println("\n--- Update Profile ---");

        System.out.print("Enter new Name (or press Enter to keep current: " + loggedInUser.getName() + "): ");
        String newName = scanner.nextLine();
        if (!newName.isEmpty()) {
            loggedInUser.setName(newName);
            System.out.println("Name updated.");
        }

        System.out.print("Enter new Email (or press Enter to keep current: " + loggedInUser.getEmail() + "): ");
        String newEmail = scanner.nextLine();
        if (!newEmail.isEmpty()) {
            loggedInUser.setEmail(newEmail);
            System.out.println("Email updated.");
        }

        System.out.print("Do you want to change your password? (yes/no): ");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            System.out.print("Enter current password: ");
            String currentPass = scanner.nextLine();
            
            if (currentPass.equals(loggedInUser.getPassword())) {
                System.out.print("Enter new password: ");
                String newPass = scanner.nextLine();
                loggedInUser.setPassword(newPass);
                System.out.println("*** Password successfully updated! ***");
            } else {
                System.out.println("!!! Current password incorrect. Password change aborted. !!!");
            }
        }
        
        System.out.println("\nProfile update complete.");
    }
    
    // --- 3, 4, 5. Exam Core, Timer, and Auto Submit ---

    private void startExam() {
        if (!userAnswers.isEmpty()) {
            System.out.print("\nYou have already taken the exam. Do you want to retake it? (yes/no): ");
            if (!scanner.nextLine().equalsIgnoreCase("yes")) {
                return;
            }
        }
        
        userAnswers.clear(); // Reset answers for a retake
        examSubmitted.set(false);
        System.out.println("\n=============================================");
        System.out.println("           EXAMINATION STARTED!");
        System.out.println("   You have " + EXAM_DURATION_SECONDS + " seconds to complete " + questions.size() + " questions.");
        System.out.println("=============================================");

        // Start the timer
        startTimer();

        // Exam Loop
        for (int i = 0; i < questions.size(); i++) {
            if (examSubmitted.get()) {
                break; // Stop if timer runs out
            }
            displayQuestion(i, questions.get(i));
        }

        // Manual submit if the loop finishes before the timer
        if (!examSubmitted.get()) {
            submitExam(false); // Manual submission
        }
    }

    private void startTimer() {
        timer = new Timer(true); // Daemon thread
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                submitExam(true); // Auto-submission
            }
        }, EXAM_DURATION_SECONDS * 1000);
        System.out.println("[INFO] Timer started for " + EXAM_DURATION_SECONDS + " seconds.");
    }

    // --- 3. Select Answers and MCQ ---
    
    private void displayQuestion(int index, Question q) {
        System.out.println("\n--- Question " + (index + 1) + " of " + questions.size() + " ---");
        System.out.println(q.getText());
        
        for (int i = 0; i < q.getOptions().size(); i++) {
            // Display options as 1. 2. 3. 4.
            System.out.println((i + 1) + ". " + q.getOptions().get(i).substring(3)); 
        }

        int selectedOption = -1;
        while (selectedOption < 1 || selectedOption > q.getOptions().size()) {
            if (examSubmitted.get()) return; // Check if auto-submitted while waiting for input
            System.out.print("Your answer (Enter 1-" + q.getOptions().size() + "): ");
            
            try {
                // Non-blocking read needed for timer, but complex in console Java.
                // We use a simple blocking read and rely on the auto-submit flag.
                String input = scanner.nextLine().trim();
                if (input.isEmpty()) continue;
                selectedOption = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        
        // Store 1-based answer index
        userAnswers.put(index, selectedOption);
    }

    // --- 4. Timer and Auto Submit Logic ---

    private void submitExam(boolean isTimeUp) {
        // Only proceed if the exam has not been submitted yet
        if (examSubmitted.compareAndSet(false, true)) {
            timer.cancel(); // Stop the timer

            if (isTimeUp) {
                System.out.println("\n\n#####################################################");
                System.out.println("!!! TIME IS UP! The examination has been AUTO-SUBMITTED. !!!");
                System.out.println("#####################################################");
            } else {
                System.out.println("\n\n#####################################################");
                System.out.println("           Examination submitted manually.");
                System.out.println("#####################################################");
            }
            
            calculateScore();
        }
    }

    private void calculateScore() {
        int correctCount = 0;
        
        System.out.println("\n--- Results Summary ---");
        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            // Get user answer (default to 0 if not answered, which is always wrong)
            int userAnswerIndex = userAnswers.getOrDefault(i, 0); 
            // Correct answer is 0-based, so we check against 1-based user input
            int correctAnswerDisplay = q.getCorrectAnswerIndex() + 1; 

            if (userAnswerIndex == correctAnswerDisplay) {
                correctCount++;
                System.out.println("Q" + (i + 1) + ": Correct!");
            } else {
                // Only show wrong if the user actually attempted the question
                if (userAnswerIndex != 0) {
                     System.out.println("Q" + (i + 1) + ": Incorrect. Correct Answer was option " + correctAnswerDisplay);
                } else {
                     System.out.println("Q" + (i + 1) + ": Not Attempted.");
                }
            }
        }
        
        double score = (double) correctCount / questions.size() * 100;

        System.out.println("\n-------------------------------------------");
        System.out.println("Total Questions: " + questions.size());
        System.out.println("Attempted: " + userAnswers.size());
        System.out.println("Correct Answers: " + correctCount);
        System.out.printf("Final Score: %.2f%%\n", score);
        System.out.println("-------------------------------------------");
    }

    // --- 5. Closing session and Logout ---
    
    private void logout() {
        if (timer != null) {
             timer.cancel();
        }
        loggedInUser = null;
        System.out.println("\n*** Session closed and logged out. Goodbye! ***");
    }

    // --- Entry Point ---
    public static void main(String[] args) {
        // Note: The timer functionality works, but the user must be ready to hit 
        // enter after typing their answer, otherwise the timer may run out 
        // while the scanner is waiting for input.
        OnlineExamSystem system = new OnlineExamSystem();
        system.start();
    }
}