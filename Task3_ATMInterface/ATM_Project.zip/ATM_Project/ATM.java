import java.util.ArrayList;
import java.util.List;

public class ATM {

    private double balance;
    private List<String> transactionHistory;

    public ATM(double initialBalance) {
        this.balance = initialBalance;
        this.transactionHistory = new ArrayList<>();
    }

    public void deposit(double amount) {
        balance += amount;
        transactionHistory.add("Deposited: " + amount);
    }

    public boolean withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            transactionHistory.add("Withdrawn: " + amount);
            return true;
        } else {
            transactionHistory.add("Failed Withdraw Attempt: " + amount);
            return false;
        }
    }

    public boolean transfer(double amount, String receiver) {
        if (amount <= balance) {
            balance -= amount;
            transactionHistory.add("Transferred " + amount + " to " + receiver);
            return true;
        } else {
            transactionHistory.add("Failed Transfer Attempt: " + amount + " to " + receiver);
            return false;
        }
    }

    public double getBalance() {
        return balance;
    }

    public List<String> getTransactionHistory() {
        return transactionHistory;
    }
}
