import java.util.Scanner;

public class ATMInterface {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ATM atm = new ATM(1000.0);

        System.out.println("Welcome to the ATM System");

        while (true) {
            System.out.println("\nSelect an option:");
            System.out.println("1. Transaction History");
            System.out.println("2. Withdraw");
            System.out.println("3. Deposit");
            System.out.println("4. Transfer");
            System.out.println("5. Exit");

            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.println("\nTransaction History:");
                    if (atm.getTransactionHistory().isEmpty()) {
                        System.out.println("No transactions yet.");
                    } else {
                        for (String record : atm.getTransactionHistory()) {
                            System.out.println(record);
                        }
                    }
                    break;

                case 2:
                    System.out.print("Enter amount to withdraw: ");
                    double withdrawAmount = sc.nextDouble();
                    if (atm.withdraw(withdrawAmount)) {
                        System.out.println("Withdraw successful.");
                    } else {
                        System.out.println("Insufficient balance.");
                    }
                    break;

                case 3:
                    System.out.print("Enter amount to deposit: ");
                    double depositAmount = sc.nextDouble();
                    atm.deposit(depositAmount);
                    System.out.println("Deposit successful.");
                    break;

                case 4:
                    System.out.print("Enter receiver name: ");
                    String receiver = sc.next();
                    System.out.print("Enter amount to transfer: ");
                    double transferAmount = sc.nextDouble();
                    if (atm.transfer(transferAmount, receiver)) {
                        System.out.println("Transfer successful.");
                    } else {
                        System.out.println("Insufficient balance.");
                    }
                    break;

                case 5:
                    System.out.println("Thank you for using the ATM.");
                    return;

                default:
                    System.out.println("Invalid option. Try again.");
                    break;
            }
        }
    }
}
